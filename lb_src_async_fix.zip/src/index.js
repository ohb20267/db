import fnbr from 'fnbr'
import express from 'express'

import deviceAuth from './../device_auth.json' with { type: 'json' }
import { readFile } from 'fs/promises';

const { Enums } = fnbr;
const { PartyPrivacy } = Enums;

let ownerId = "";
try {
    ownerId = await readFile('./../owner.txt', 'utf8');
} catch (error) {
    console.error("Error reading file: ", error);
}

let client = new fnbr.Client({
    auth: {
        deviceAuth: deviceAuth
    },
    defaultStatus: 'Pro Swapper Lobby Bot',
    partyConfig: {
        joinability: 'INVITE_AND_FORMER',
        privacy: PartyPrivacy.PRIVATE
    }
});

client.on('ready', async () => {
    console.log(`Client is ready (${client.user.self.displayName})`)
    client.friend.pendingList.forEach(pending => {
        if (pending.direction == "INCOMING")
            pending.decline();
    });
})

client.on('party:invite', async (invitation) => {
    try {
        if (invitation.sender.id != ownerId)
            return;

        await invitation.accept();
    } catch (ex) {
        console.error(ex);
    }
});

client.on('friend:request', async (invitation) => {
    try {
        if (invitation.id != ownerId)
            return;

        await invitation.accept();
    } catch (ex) {
        console.error(ex);
    }
});

let outfit = null;
let backpack = null;
let pickaxe = null;

client.on('party:member:joined', async (member) => {
    try {
        if (outfit)
            await setCosmetic('AthenaCharacter', outfit);

        if (backpack)
            await setCosmetic('AthenaBackpack', backpack);

        if (pickaxe)
            await setCosmetic('AthenaPickaxe', pickaxe);

        await client.party.me.setSittingOut(true);
        await client.party.me.setEmote('EID_IceKing');
    } catch (ex) {
        console.error(ex);
    }
});

const app = express();
const PORT = 7701;

app.get('/set', async (req, res) => {
    try {
        const type = req.query['type'];
        const id = req.query['id'];
        
        await setCosmetic(type, id);
        res.send(200);
    }
    catch (ex) {
        res.status(500).send(ex);
    }
});

app.listen(PORT, () => {
    console.log(`Server is running at http://localhost:${PORT}`);
})

async function setCosmetic(type, id)
{
    switch (type) {
        case 'AthenaCharacter':
            outfit = id;
            await client.party.me.setOutfit(id);
            break;
        case 'AthenaBackpack':
            backpack = id;
            await client.party.me.setBackpack(id);
            break;
        case 'AthenaPickaxe':
            pickaxe = id;
            await client.party.me.setPickaxe(id);
            break;
    }

    console.log(`Applied cosmetic: ${type}:${id}`);
}

await client.login();